data "azurerm_app_service_plan" "asp" {
  name                = "zip-serve-stg-asp"
  resource_group_name = "zip-serve-stg-fe"
}

module "webapp_meals" {
  source              = "../../modules/webapp"
  app_name            = "zip-serve-stg-meals"
  location            = var.location
  resource_group_name = "zip-serve-stg-fe"
  app_service_plan_id = data.azurerm_app_service_plan.asp.id
}